# -*- coding: utf-8 -*-
"""plugin.image.navarre - comic-cover browser for the Navarre skin.

Kodi's native Pictures window browses each .cbz/.cbr as a folder and montages
its first few inner pages into the tile thumbnail, ignoring any cover sidecar
image. This plugin lists a comics folder so that every tile shows the comic's
REAL first page (the cover), and a click descends into the archive so Kodi's own
picture viewer reads the pages exactly as before.

Covers are extracted once and cached under the add-on profile, keyed by the
archive's path + modified-time + size so a re-tagged/replaced file re-derives:
  * .cbz - read with the Python standard-library `zipfile` (no add-on needed)
           when the file is local; falls back to Kodi's VFS for network sources.
  * .cbr - read through Kodi's `rar://` VFS (vfs.rar), since the standard library
           has no RAR support and we ship no third-party packages.
Nothing is transcoded - Kodi's own texture cache scales whatever JPG/PNG/WebP we
hand to setArt, the same way it does for a movie poster.

Routes:
  plugin://plugin.image.navarre/?dir=<folder>             -> list a comics folder
  plugin://plugin.image.navarre/?action=read&archive=<p>  -> read from page 1
"""
import sys
import os
import re
import hashlib
import zipfile
from urllib.parse import urlencode, parse_qsl, quote

import xbmc
import xbmcgui
import xbmcvfs
import xbmcplugin

ADDON_ID = 'plugin.image.navarre'
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
BASE = sys.argv[0]

IMAGE_EXTS = ('.jpg', '.jpeg', '.png', '.webp', '.gif', '.bmp')
COMIC_EXTS = ('.cbz', '.cbr')
CACHE_DIR = xbmcvfs.translatePath(
    'special://profile/addon_data/%s/covers/' % ADDON_ID)
FALLBACK_ART = 'DefaultPicture.png'


def _log(msg):
    xbmc.log('[%s] %s' % (ADDON_ID, msg), xbmc.LOGDEBUG)


def _warn(msg):
    # WARNING level so cover-extraction failures show in a normal Kodi log,
    # without the user having to turn on debug logging.
    xbmc.log('[%s] %s' % (ADDON_ID, msg), xbmc.LOGWARNING)


def _natural_key(name):
    """Case-insensitive natural sort so '2.jpg' sorts before '10.jpg' and the
    cover (the lowest-numbered page) lands first."""
    s = (name or '').lower()
    return [int(t) if t.isdigit() else t for t in re.split(r'(\d+)', s)]


def _is_image(name):
    """True for an archive entry that is an actual page image - skips directory
    entries, macOS resource forks and hidden dotfiles (ComicInfo.xml, Thumbs.db,
    .nfo all fail the extension test)."""
    if not name or name.endswith('/'):
        return False
    if name.startswith('__MACOSX/'):
        return False
    base = name.rsplit('/', 1)[-1].rsplit('\\', 1)[-1]
    if not base or base.startswith('.'):
        return False
    return name.lower().endswith(IMAGE_EXTS)


def _archive_url(path, proto=None):
    """VFS root URL addressing the contents of an archive: rar:// for .cbr (via
    vfs.rar), archive:// for .cbz/.zip (via vfs.libarchive). The whole archive
    path is percent-encoded into the host segment; the trailing slash lists the
    root. Pass proto to force a reader (used to retry a file whose extension
    lies)."""
    if proto is None:
        proto = 'rar' if path.lower().endswith('.cbr') else 'archive'
    return '%s://%s/' % (proto, quote(path, safe=''))


# ---- cover extraction ----------------------------------------------------

def _cover_from_zip(path):
    """First page of a local .cbz via the standard library - no add-on
    dependency, works offline. Returns image bytes or None."""
    with zipfile.ZipFile(path, 'r') as zf:
        names = [n for n in zf.namelist() if _is_image(n)]
        if not names:
            return None
        names.sort(key=_natural_key)
        return zf.read(names[0])


def _entry_url(root, inner):
    """URL for an inner archive path. vfs.rar wants the inner path LITERAL
    (un-encoded) appended to the url-encoded archive root - confirmed by probing
    real files: every percent-encoded form read 0 bytes, the raw path read the
    whole image. So '#', spaces, parentheses and brackets go through verbatim;
    vfs.rar does NOT url-decode the inner path (encoding it is what broke the
    messily-named .cbr covers). Only the archive path itself (in `root`) is
    encoded."""
    return root + inner


def _cover_from_vfs(path, proto=None):
    """First page via Kodi's VFS (rar:// for .cbr, archive:// for zip),
    recursing through any nested subfolders. Returns image bytes or None. One
    read retry, since vfs.rar can transiently fail when many archives are opened
    back to back."""
    root = _archive_url(path, proto)
    imgs = []         # (inner_path, entry_url)
    stack = ['']      # decoded inner-path prefixes ('' = the archive root)
    guard = 0
    while stack and guard < 4000:
        prefix = stack.pop()
        try:
            dirs, files = xbmcvfs.listdir(_entry_url(root, prefix))
        except Exception:
            dirs, files = [], []
        for f in files:
            guard += 1
            inner = prefix + f
            if _is_image(inner):
                imgs.append((inner, _entry_url(root, inner)))
        for d in dirs:
            stack.append(prefix + d + '/')
    if not imgs:
        return None
    imgs.sort(key=lambda t: _natural_key(t[0]))
    for _attempt in range(2):
        handle = xbmcvfs.File(imgs[0][1])
        try:
            data = bytes(handle.readBytes())
        finally:
            handle.close()
        if data:
            return data
    return None


def _diag_listing(path):
    """One-line dump of what Kodi's VFS returns for an archive whose cover we
    couldn't read - e.g. a SOLID rar (vfs.rar lists members but can't read past
    the first) shows files present yet unreadable. Kept (cheap) so a user's
    failure is diagnosable from a normal log."""
    try:
        root = _archive_url(path)
        dirs, files = xbmcvfs.listdir(root)
        return 'dirs=%r files=%r' % (list(dirs)[:5], list(files)[:5])
    except Exception as exc:
        return 'listdir error: %s' % exc


def _cache_path(path):
    """Stable cache filename: sha1 of path + mtime + size, so editing or
    replacing the archive yields a fresh cover automatically."""
    try:
        st = xbmcvfs.Stat(path)
        sig = '%s|%d|%d' % (path, int(st.st_mtime()), st.st_size())
    except Exception:
        sig = path
    return os.path.join(CACHE_DIR, hashlib.sha1(sig.encode('utf-8')).hexdigest()
                        + '.jpg')


def get_cover(path):
    """Return a local cached cover-image path for a comic archive, extracting it
    on first use. Returns '' if the cover can't be read (caller falls back to a
    generic icon - the comic still lists and opens)."""
    if not xbmcvfs.exists(CACHE_DIR):
        xbmcvfs.mkdirs(CACHE_DIR)
    out = _cache_path(path)
    if xbmcvfs.exists(out):
        return out
    data = None
    reason = ''
    lower = path.lower()
    try:
        if lower.endswith('.cbz'):
            if os.path.isfile(path):
                data = _cover_from_zip(path)            # local zip, stdlib
            if data is None:
                data = _cover_from_vfs(path, 'archive')  # network zip, libarchive
        else:
            # .cbr -> vfs.rar only. It is the one reader that handles solid and
            # all RAR3/RAR5 compression; archive:// (libarchive) is a dead end
            # for RAR (it throws "solid archive support unavailable"), so there
            # is no point falling back to it.
            data = _cover_from_vfs(path, 'rar')
    except Exception as exc:
        reason = 'exception: %s' % exc
    if not data:
        _warn('no cover for "%s" (%s) | %s'
              % (os.path.basename(path), reason or 'no image entries found',
                 _diag_listing(path)))
        return ''
    tmp = out + '.tmp'
    try:
        handle = xbmcvfs.File(tmp, 'w')
        try:
            handle.write(bytearray(data))
        finally:
            handle.close()
        if xbmcvfs.exists(out):
            xbmcvfs.delete(out)
        xbmcvfs.rename(tmp, out)  # atomic publish, so a half-written file is
        # never handed to setArt
    except Exception as exc:
        _log('cover cache write failed for %s: %s' % (path, exc))
        return ''
    return out


# ---- listing -------------------------------------------------------------

def _title(name):
    """Clean on-screen label - drop the archive extension."""
    dot = name.rfind('.')
    return name[:dot] if dot > 0 else name


def _sep_of(folder):
    """The path separator this folder uses (backslash on Windows, forward slash
    on Android/SMB) so child paths keep a consistent, valid style."""
    if folder.endswith('\\'):
        return '\\'
    if folder.endswith('/'):
        return '/'
    return '\\' if ('\\' in folder and '/' not in folder) else '/'


def _folder_art(sub):
    """A folder tile uses its own poster/folder image when present, else a
    generic folder icon."""
    for cand in ('poster.jpg', 'folder.jpg', 'cover.jpg'):
        if xbmcvfs.exists(sub + cand):
            return sub + cand
    return 'DefaultFolder.png'


def list_dir(folder):
    """List a comics folder: subfolders first (browse into them), then each
    .cbz/.cbr as a cover-arted tile that opens its pages on click."""
    xbmcplugin.setContent(HANDLE, 'images')
    if not folder:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    sep = _sep_of(folder)
    if not folder.endswith(('\\', '/')):
        folder += sep
    try:
        dirs, files = xbmcvfs.listdir(folder)
    except Exception as exc:
        _log('listdir failed for %s: %s' % (folder, exc))
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    for d in sorted(dirs, key=_natural_key):
        sub = folder + d + sep
        li = xbmcgui.ListItem(label=d)
        art = _folder_art(sub)
        li.setArt({'thumb': art, 'poster': art, 'icon': 'DefaultFolder.png'})
        url = BASE + '?' + urlencode({'dir': sub})
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)

    comics = sorted((f for f in files if f.lower().endswith(COMIC_EXTS)),
                    key=_natural_key)
    progress = None
    if len(comics) > 8:
        # First open of a big folder extracts every cover; a background bar keeps
        # it from looking frozen. Cached runs skip extraction and never show it.
        progress = xbmcgui.DialogProgressBG()
        progress.create('Navarre', 'Reading comic covers')
    try:
        for index, f in enumerate(comics):
            full = folder + f
            li = xbmcgui.ListItem(label=_title(f))
            cover = get_cover(full)
            if cover:
                li.setArt({'thumb': cover, 'poster': cover})
            else:
                li.setArt({'thumb': FALLBACK_ART, 'poster': FALLBACK_ART,
                           'icon': FALLBACK_ART})
            read_url = BASE + '?' + urlencode({'action': 'read', 'archive': full})
            li.addContextMenuItems(
                [('Read from start', 'RunPlugin(%s)' % read_url)])
            # isFolder + the archive VFS url: clicking descends into the comic's
            # pages in the Pictures window (then a page opens the slideshow),
            # reusing Kodi's native reader. We only override the cover tile.
            xbmcplugin.addDirectoryItem(HANDLE, _archive_url(full), li,
                                        isFolder=True)
            if progress:
                progress.update(int((index + 1) * 100 / len(comics)))
    finally:
        if progress:
            progress.close()
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
    # Pin the portrait poster wall (517) so covers show as a wall on EVERY
    # listing - root and each series subfolder. The skin's forced-view system
    # is content-keyed and can't target this plugin (the Pictures window reports
    # empty content for it), and the menu item now opens us with a plain
    # ActivateWindow (no view-setting launcher), so we set it here. The short
    # sleep lets the container finish rendering before the view switch, and the
    # window guard keeps a stray call elsewhere a no-op.
    if xbmc.getCondVisibility('Window.IsVisible(MyPics.xml)'):
        xbmc.sleep(150)
        xbmc.executebuiltin('Container.SetViewMode(517)')


def read_archive(path):
    """Open a comic full-screen from page 1 (the optional 'Read from start'
    context action)."""
    if not path:
        return
    xbmc.executebuiltin('SlideShow(%s,notrandom)' % _archive_url(path))


def router():
    params = {}
    if len(sys.argv) > 2 and sys.argv[2].startswith('?'):
        params = dict(parse_qsl(sys.argv[2][1:]))
    # parse_qsl has already percent-decoded the values, so use them as-is.
    if params.get('action') == 'read':
        read_archive(params.get('archive', ''))
    else:
        list_dir(params.get('dir', ''))


if __name__ == '__main__':
    router()
