# -*- coding: utf-8 -*-
"""plugin.image.navarre - comic-cover browser for the Navarre skin.

Kodi's native Pictures window browses each .cbz/.cbr/.pdf as a folder and
montages its first few inner pages into the tile thumbnail, ignoring any cover
sidecar image. This plugin lists a comics folder so that every tile shows the
comic's REAL first page (the cover), and a click descends into the archive so
Kodi's own picture viewer reads the pages exactly as before.

Covers are extracted once and cached under the add-on profile, keyed by the
archive's path + modified-time + size so a re-tagged/replaced file re-derives:
  * .cbz - read with the Python standard-library `zipfile` (no add-on needed)
           when the file is local; falls back to Kodi's VFS for network sources.
  * .cbr - read through Kodi's `rar://` VFS (vfs.rar), since the standard library
           has no RAR support and we ship no third-party packages.
  * .pdf - scanned-comic pages are embedded JPEGs (DCTDecode), so the cover (and
           every page, for reading) is pulled straight out of the PDF byte
           stream in pure Python - no render library.
Nothing is transcoded - Kodi's own texture cache scales whatever JPG/PNG/WebP we
hand to setArt, the same way it does for a movie poster.

Big folders (hundreds of comics) used to stall: every cover was extracted
synchronously before the listing showed, so Kodi gave up part way and the user
had to back out and re-enter to fill the rest. Now a large folder lists
instantly with whatever covers are already cached, and a background pass
(?action=warm, launched with RunPlugin so it outlives this invocation) extracts
the rest and refreshes the wall in waves as they land.

Routes:
  plugin://plugin.image.navarre/?dir=<folder>             -> list a comics folder
  plugin://plugin.image.navarre/?action=warm&dir=<folder> -> background cover fill
  plugin://plugin.image.navarre/?action=read&archive=<p>  -> read .cbz/.cbr
  plugin://plugin.image.navarre/?action=pdfpages&pdf=<p>   -> list a PDF's pages
  plugin://plugin.image.navarre/?action=readpdf&pdf=<p>    -> read a PDF (slideshow)
"""
import os
import re
import sys
import time
import json
import hashlib
import zipfile
from urllib.parse import urlencode, parse_qsl, quote

import xbmc
import xbmcgui
import xbmcvfs
import xbmcplugin

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import pdfcomic  # sibling module - pure-Python comic-PDF reader

ADDON_ID = 'plugin.image.navarre'
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
BASE = sys.argv[0]

IMAGE_EXTS = ('.jpg', '.jpeg', '.png', '.webp', '.gif', '.bmp')
ARCHIVE_EXTS = ('.cbz', '.cbr')
PDF_EXTS = ('.pdf',)
COMIC_EXTS = ARCHIVE_EXTS + PDF_EXTS

_PROFILE = 'special://profile/addon_data/%s/' % ADDON_ID
CACHE_DIR = xbmcvfs.translatePath(_PROFILE + 'covers/')
PAGES_DIR = xbmcvfs.translatePath(_PROFILE + 'pdf_pages/')
FALLBACK_ART = 'DefaultPicture.png'

# Comic poster wall (portrait tiles) and the square grid used for a PDF's
# extracted pages. Pinned after each listing - the Pictures window reports empty
# Container.Content for a plugin, so the skin's content-keyed forced views can't
# target us.
WALL_VIEW = 517
PAGES_VIEW = 500

# Folders with more comics than this fill their covers in the background; smaller
# folders extract inline so their covers show immediately with no fallback flash.
INLINE_LIMIT = 8
# While the background warmer runs, refresh the on-screen wall at most this often
# (seconds) so new covers appear in waves without the view jumping every second.
REFRESH_SECS = 4.0

# Window-property channel between a foreground listing and the background warmer
# (Home window 10000 is always alive). The warmer follows whichever Navarre
# folder the user is viewing, so only one ever runs.
_HOME = 10000
_BUSY_PROP = 'navarre.cover.warm.busy'

# An archive reader (.cbr -> vfs.rar, network .cbz -> vfs.libarchive) is only
# usable once it's installed AND enabled. Checked via the add-on manager and
# memoised per plugin invocation (each RunPlugin is a fresh process, so a
# mid-session install is seen on the next browse). _READER_LABELS feeds the
# one-tap install prompt.
_READER_OK = {}
_READER_LABELS = {
    'vfs.rar': 'RAR support (for .cbr comics)',
    'vfs.libarchive': 'Archive support (for .cbz comics)',
}


def _log(msg):
    xbmc.log('[%s] %s' % (ADDON_ID, msg), xbmc.LOGDEBUG)


def _warn(msg):
    # WARNING level so cover-extraction failures show in a normal Kodi log,
    # without the user having to turn on debug logging.
    xbmc.log('[%s] %s' % (ADDON_ID, msg), xbmc.LOGWARNING)


def _natural_key(name):
    """Case-insensitive natural sort so '2.jpg' sorts before '10.jpg' and the
    cover (the lowest-numbered page) lands first."""
    s = (name or '').lower()
    return [int(t) if t.isdigit() else t for t in re.split(r'(\d+)', s)]


def _is_image(name):
    """True for an archive entry that is an actual page image - skips directory
    entries, macOS resource forks and hidden dotfiles (ComicInfo.xml, Thumbs.db,
    .nfo all fail the extension test)."""
    if not name or name.endswith('/'):
        return False
    if name.startswith('__MACOSX/'):
        return False
    base = name.rsplit('/', 1)[-1].rsplit('\\', 1)[-1]
    if not base or base.startswith('.'):
        return False
    return name.lower().endswith(IMAGE_EXTS)


def _archive_url(path, proto=None):
    """VFS root URL addressing the contents of an archive: rar:// for .cbr (via
    vfs.rar), archive:// for .cbz/.zip (via vfs.libarchive). The whole archive
    path is percent-encoded into the host segment; the trailing slash lists the
    root. Pass proto to force a reader (used to retry a file whose extension
    lies)."""
    if proto is None:
        proto = 'rar' if path.lower().endswith('.cbr') else 'archive'
    return '%s://%s/' % (proto, quote(path, safe=''))


# ---- archive cover extraction --------------------------------------------

def _cover_from_zip(path):
    """First page of a local .cbz via the standard library - no add-on
    dependency, works offline. Returns image bytes or None."""
    with zipfile.ZipFile(path, 'r') as zf:
        names = [n for n in zf.namelist() if _is_image(n)]
        if not names:
            return None
        names.sort(key=_natural_key)
        return zf.read(names[0])


def _entry_url(root, inner):
    """URL for an inner archive path. vfs.rar wants the inner path LITERAL
    (un-encoded) appended to the url-encoded archive root - confirmed by probing
    real files: every percent-encoded form read 0 bytes, the raw path read the
    whole image. So '#', spaces, parentheses and brackets go through verbatim;
    vfs.rar does NOT url-decode the inner path (encoding it is what broke the
    messily-named .cbr covers). Only the archive path itself (in `root`) is
    encoded."""
    return root + inner


def _walk_archive_images(path, proto=None):
    """Every page image in an archive as sorted (inner_path, entry_url) pairs,
    recursing through nested subfolders. Shared by cover extraction (takes the
    first) and page listing (takes them all), so both see the same order."""
    root = _archive_url(path, proto)
    imgs = []         # (inner_path, entry_url)
    stack = ['']      # decoded inner-path prefixes ('' = the archive root)
    guard = 0
    while stack and guard < 4000:
        prefix = stack.pop()
        try:
            dirs, files = xbmcvfs.listdir(_entry_url(root, prefix))
        except Exception:
            dirs, files = [], []
        for f in files:
            guard += 1
            inner = prefix + f
            if _is_image(inner):
                imgs.append((inner, _entry_url(root, inner)))
        for d in dirs:
            stack.append(prefix + d + '/')
    imgs.sort(key=lambda t: _natural_key(t[0]))
    return imgs


def _cover_from_vfs(path, proto=None):
    """First page via Kodi's VFS (rar:// for .cbr, archive:// for zip). Returns
    image bytes or None. One read retry, since vfs.rar can transiently fail when
    many archives are opened back to back."""
    imgs = _walk_archive_images(path, proto)
    if not imgs:
        return None
    for _attempt in range(2):
        handle = xbmcvfs.File(imgs[0][1])
        try:
            data = bytes(handle.readBytes())
        finally:
            handle.close()
        if data:
            return data
    return None


def _diag_listing(path):
    """One-line dump of what Kodi's VFS returns for an archive whose cover we
    couldn't read - e.g. a SOLID rar (vfs.rar lists members but can't read past
    the first) shows files present yet unreadable. Kept (cheap) so a user's
    failure is diagnosable from a normal log."""
    try:
        root = _archive_url(path)
        dirs, files = xbmcvfs.listdir(root)
        return 'dirs=%r files=%r' % (list(dirs)[:5], list(files)[:5])
    except Exception as exc:
        return 'listdir error: %s' % exc


# ---- PDF cover / page extraction -----------------------------------------
# Comic PDFs store each page as an embedded JPEG; pdfcomic pulls them out in
# reading order, decrypting RC4 copy-protected files (common on commercial comic
# DVD sets) along the way - all pure stdlib, no third-party package. Reading is
# capped so a pathologically large PDF can't exhaust memory on a Shield.

_PDF_READ_CAP = 256 << 20   # 256 MiB - far above any real comic issue


def _read_bytes(path, cap=_PDF_READ_CAP):
    """Whole-file bytes (up to a cap) for in-memory PDF parsing."""
    handle = xbmcvfs.File(path)
    try:
        out = bytearray()
        while len(out) < cap:
            chunk = handle.readBytes(1 << 22)   # 4 MiB reads
            if not chunk:
                break
            out += bytes(chunk)
        return bytes(out)
    finally:
        handle.close()


def _pdf_cover(path):
    """Cover (first page) of a comic PDF, or None."""
    return pdfcomic.cover(_read_bytes(path))


# ---- cover cache ---------------------------------------------------------

def _sig(path):
    """Signature that changes when the file is edited/replaced (path|mtime|size),
    so a new version re-derives its cover automatically."""
    try:
        st = xbmcvfs.Stat(path)
        return '%s|%d|%d' % (path, int(st.st_mtime()), st.st_size())
    except Exception:
        return path


def _hash(path):
    return hashlib.sha1(_sig(path).encode('utf-8')).hexdigest()


def _cache_path(path):
    return os.path.join(CACHE_DIR, _hash(path) + '.jpg')


def _fail_path(path):
    """Sentinel marking 'we tried and there is no extractable cover' (a solid
    RAR whose cover isn't first, a non-DCTDecode PDF, an empty archive). Keyed by
    the same signature, so it clears the moment the file changes. Stops the
    background warmer from re-opening a hopeless archive on every browse."""
    return os.path.join(CACHE_DIR, _hash(path) + '.fail')


def cached_cover(path):
    """Local cached cover path if it already exists, else '' (no extraction)."""
    out = _cache_path(path)
    return out if xbmcvfs.exists(out) else ''


def is_resolved(path):
    """True once we have either a cover or a definitive failure for this file -
    i.e. the warmer has nothing left to do for it."""
    return xbmcvfs.exists(_cache_path(path)) or xbmcvfs.exists(_fail_path(path))


def _extract_cover_bytes(path):
    """Dispatch cover extraction by type. Returns image bytes or None."""
    lower = path.lower()
    if lower.endswith('.pdf'):
        return _pdf_cover(path)
    if lower.endswith('.cbz'):
        data = _cover_from_zip(path) if os.path.isfile(path) else None
        if data is None:
            data = _cover_from_vfs(path, 'archive')  # network zip, libarchive
        return data
    # .cbr -> vfs.rar only. It is the one reader that handles solid and all
    # RAR3/RAR5 compression; archive:// (libarchive) throws on solid RAR, so
    # there is no point falling back to it.
    return _cover_from_vfs(path, 'rar')


def _addon_usable(addon_id, force=False):
    """True only if the add-on is installed AND enabled. System.HasAddon is no
    good here - it reports true for an installed-but-DISABLED add-on - so ask the
    add-on manager directly (in-process JSON-RPC, so it works even with the web
    server off). Memoised for this invocation; pass force=True to re-query (used
    while waiting for a just-triggered install to land)."""
    if not force and addon_id in _READER_OK:
        return _READER_OK[addon_id]
    ok = False
    try:
        req = ('{"jsonrpc":"2.0","id":1,"method":"Addons.GetAddonDetails",'
               '"params":{"addonid":"%s","properties":["enabled"]}}' % addon_id)
        resp = json.loads(xbmc.executeJSONRPC(req))
        ok = bool(resp.get('result', {}).get('addon', {}).get('enabled'))
    except Exception:
        ok = False
    _READER_OK[addon_id] = ok
    return ok


def _missing_reader(path):
    """The archive reader this comic needs but doesn't have (installed +
    enabled), or '' if it's readable now. A .cbr always needs vfs.rar; a NETWORK
    .cbz needs vfs.libarchive (a local .cbz is read with the standard library);
    a .pdf needs neither."""
    low = path.lower()
    if low.endswith('.cbr'):
        return '' if _addon_usable('vfs.rar') else 'vfs.rar'
    if low.endswith('.cbz') and not os.path.isfile(path):
        return '' if _addon_usable('vfs.libarchive') else 'vfs.libarchive'
    return ''


def _prompt_install_reader(addon_id):
    """Offer a one-tap install of a missing archive reader, at most once per Kodi
    session (a Home-window flag keeps repeat listings from nagging). Returns True
    if the user chose to install (so the caller can wait for it and fill the
    covers in), False otherwise. We don't ask again this session either way."""
    win = xbmcgui.Window(_HOME)
    flag = 'navarre.reader.asked.%s' % addon_id
    if win.getProperty(flag) == '1':
        return False
    win.setProperty(flag, '1')
    label = _READER_LABELS.get(addon_id, addon_id)
    if xbmcgui.Dialog().yesno(
            'Navarre comics',
            'Some comics here need Kodi\'s %s to show their covers and open. '
            'Install it now?' % label,
            yeslabel='Install', nolabel='Later'):
        xbmc.executebuiltin('InstallAddon(%s)' % addon_id)
        return True
    return False


def _wait_for_reader(addon_id, monitor, timeout=120):
    """Wait (in the background warmer) for a just-triggered reader install to
    finish, so the covers it unlocks fill in without the user backing out and
    re-entering. Returns True once the reader is usable, False if it never
    arrives (install cancelled or failed). Silent - Kodi shows its own install
    progress - and abort-aware so a Kodi shutdown ends it at once."""
    if _addon_usable(addon_id, force=True):
        return True
    waited = 0
    while waited < timeout and not monitor.abortRequested():
        if monitor.waitForAbort(2.0):
            break
        waited += 2
        if _addon_usable(addon_id, force=True):
            return True
    return _addon_usable(addon_id, force=True)


def get_cover(path):
    """Return a local cached cover path for a comic, extracting on first use.
    Returns '' when no cover can be read (the caller falls back to a generic
    icon; the comic still lists and opens) and records a .fail sentinel so the
    failure isn't retried until the file changes."""
    if not xbmcvfs.exists(CACHE_DIR):
        xbmcvfs.mkdirs(CACHE_DIR)
    out = _cache_path(path)
    if xbmcvfs.exists(out):
        return out
    if _missing_reader(path):
        # The reader isn't installed/enabled yet - a transient, fixable state.
        # Do NOT record a .fail (that would stop the cover ever appearing once
        # the reader is added); leave the cover unresolved so it fills in on the
        # next browse. Offering the install is list_dir's job, so the background
        # warmer never blocks on a modal and never warms un-resolvable files.
        return ''
    data = None
    reason = ''
    try:
        data = _extract_cover_bytes(path)
    except Exception as exc:
        reason = 'exception: %s' % exc
    if not data:
        diag = '' if path.lower().endswith('.pdf') else ' | ' + _diag_listing(path)
        _warn('no cover for "%s" (%s)%s'
              % (os.path.basename(path), reason or 'no image entries found',
                 diag))
        _touch(_fail_path(path))
        return ''
    if _write_atomic(out, data):
        return out
    return ''


def _write_atomic(out, data):
    """Write image bytes to `out` via a temp file + rename, so a half-written
    file is never handed to setArt. Returns True on success."""
    tmp = out + '.tmp'
    try:
        handle = xbmcvfs.File(tmp, 'w')
        try:
            handle.write(bytearray(data))
        finally:
            handle.close()
        if xbmcvfs.exists(out):
            xbmcvfs.delete(out)
        xbmcvfs.rename(tmp, out)
        return True
    except Exception as exc:
        _log('cache write failed for %s: %s' % (out, exc))
        return False


def _touch(path):
    try:
        handle = xbmcvfs.File(path, 'w')
        handle.write(bytearray(b''))
        handle.close()
    except Exception:
        pass


# ---- background cover warmer ---------------------------------------------

def _list_comics(folder):
    """Full paths of the comics in a folder, in display (natural-sort) order."""
    sep = _sep_of(folder)
    if not folder.endswith(('\\', '/')):
        folder += sep
    try:
        _dirs, files = xbmcvfs.listdir(folder)
    except Exception:
        return []
    return [folder + f for f in
            sorted((f for f in files if f.lower().endswith(COMIC_EXTS)),
                   key=_natural_key)]


def _current_navarre_dir():
    """The comics folder the user is currently viewing in this plugin, decoded,
    or '' if they're not on one of our listings."""
    fp = xbmc.getInfoLabel('Container.FolderPath') or ''
    if fp.startswith('plugin://%s/' % ADDON_ID) and '?' in fp:
        params = dict(parse_qsl(fp.split('?', 1)[1]))
        return params.get('dir', '')
    return ''


def _refresh_if_viewing(folder):
    """Reload the wall (so freshly-cached covers replace fallbacks) only while
    the user is still on that folder, so the view never jumps under them
    elsewhere."""
    if _current_navarre_dir() == folder:
        xbmc.executebuiltin('Container.Refresh')


def warm(initial_folder, await_reader=''):
    """Background pass that extracts the covers a listing left as fallbacks and
    refreshes the wall in waves. Follows whichever Navarre folder the user moves
    to, so a single warmer serves the whole browse. Launched via RunPlugin so it
    is a separate invocation that outlives the listing that started it.

    await_reader (an add-on id) means the user just chose to install that reader:
    wait for it to land, then warm - so the covers fill in without re-entering."""
    win = xbmcgui.Window(_HOME)
    if win.getProperty(_BUSY_PROP) == '1':
        return  # a warmer is already following the user
    win.setProperty(_BUSY_PROP, '1')
    monitor = xbmc.Monitor()
    progress = None
    folder = initial_folder
    guard = 0
    try:
        if await_reader and not _wait_for_reader(await_reader, monitor):
            return  # install cancelled/failed; covers fill on a later browse
        while not monitor.abortRequested() and guard < 200:
            guard += 1
            live = _current_navarre_dir()
            if live:
                folder = live
            if not folder:
                break
            pending = [c for c in _list_comics(folder) if not is_resolved(c)]
            if not pending:
                break  # current folder fully covered - done
            if progress is None:
                progress = xbmcgui.DialogProgressBG()
                progress.create('Navarre', 'Reading comic covers')
            total = len(pending)
            last_refresh = 0.0
            made_progress = False
            completed_pass = True
            new_covers = 0          # real covers cached since the last refresh
            for index, comic in enumerate(pending):
                if monitor.abortRequested():
                    completed_pass = False
                    break
                here = _current_navarre_dir()
                if here and here != folder:
                    completed_pass = False
                    break  # user moved to another folder; restart on it
                if get_cover(comic):
                    new_covers += 1     # a real cover landed - worth showing
                if is_resolved(comic):
                    made_progress = True
                progress.update(int((index + 1) * 100 / total), 'Navarre',
                                'Reading comic covers (%d/%d)' % (index + 1, total))
                now = time.time()
                # Refresh the wall only when there's a NEW cover to show. A
                # fruitless pass must not refresh: that would re-list -> re-warm
                # endlessly when a needed reader is missing (the hang we hit).
                if new_covers and now - last_refresh >= REFRESH_SECS:
                    _refresh_if_viewing(folder)
                    last_refresh = now
                    new_covers = 0
                monitor.waitForAbort(0.02)
            if new_covers:
                _refresh_if_viewing(folder)
            if completed_pass and not made_progress:
                # A full pass resolved nothing (e.g. a needed archive reader
                # isn't installed yet, so these covers can't be read now and we
                # deliberately don't .fail them) - stop rather than spin over the
                # same un-resolvable files on every pass.
                break
    finally:
        if progress:
            progress.close()
        win.setProperty(_BUSY_PROP, '')


# ---- listing -------------------------------------------------------------

def _title(name):
    """Clean on-screen label - drop the archive extension."""
    dot = name.rfind('.')
    return name[:dot] if dot > 0 else name


def _sep_of(folder):
    """The path separator this folder uses (backslash on Windows, forward slash
    on Android/SMB) so child paths keep a consistent, valid style."""
    if folder.endswith('\\'):
        return '\\'
    if folder.endswith('/'):
        return '/'
    return '\\' if ('\\' in folder and '/' not in folder) else '/'


def _folder_art(sub):
    """A folder tile uses its own poster/folder image when present, else a
    generic folder icon."""
    for cand in ('poster.jpg', 'folder.jpg', 'cover.jpg'):
        if xbmcvfs.exists(sub + cand):
            return sub + cand
    return 'DefaultFolder.png'


def _comic_urls(full):
    """(item_url, read_url) for a comic tile. Both archives and PDFs route their
    page list through the plugin so we can pin the same poster wall on every
    platform. (Letting Kodi browse a .cbr/.cbz natively instead leaves the page
    list in whatever view that window last used - a tidy wall on PC, an ugly
    list+preview on Android. Routing through the plugin makes it deterministic.)
    Kodi still can't open a .pdf in the picture viewer, hence the separate
    extract-to-images route for those."""
    if full.lower().endswith('.pdf'):
        item = BASE + '?' + urlencode({'action': 'pdfpages', 'pdf': full})
        read = BASE + '?' + urlencode({'action': 'readpdf', 'pdf': full})
    else:
        item = BASE + '?' + urlencode({'action': 'archivepages', 'archive': full})
        read = BASE + '?' + urlencode({'action': 'read', 'archive': full})
    return item, read


def list_dir(folder):
    """List a comics folder: subfolders first, then each comic as a cover-arted
    tile that opens its pages on click. Big folders show instantly with cached
    covers and fill the rest in the background; small ones extract inline."""
    xbmcplugin.setContent(HANDLE, 'images')
    if not folder:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    sep = _sep_of(folder)
    if not folder.endswith(('\\', '/')):
        folder += sep
    try:
        dirs, files = xbmcvfs.listdir(folder)
    except Exception as exc:
        _log('listdir failed for %s: %s' % (folder, exc))
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    for d in sorted(dirs, key=_natural_key):
        sub = folder + d + sep
        li = xbmcgui.ListItem(label=d)
        art = _folder_art(sub)
        li.setArt({'thumb': art, 'poster': art, 'icon': 'DefaultFolder.png'})
        url = BASE + '?' + urlencode({'dir': sub})
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=True)

    comics = sorted((f for f in files if f.lower().endswith(COMIC_EXTS)),
                    key=_natural_key)
    inline = len(comics) <= INLINE_LIMIT
    progress = None
    if inline and len(comics) > 2:
        progress = xbmcgui.DialogProgressBG()
        progress.create('Navarre', 'Reading comic covers')
    unresolved = 0          # covers the warmer can still resolve (reader present)
    missing_reader = ''     # an archive reader a comic needs but doesn't have
    try:
        for index, f in enumerate(comics):
            full = folder + f
            li = xbmcgui.ListItem(label=_title(f))
            cover = cached_cover(full)
            if not cover and inline:
                cover = get_cover(full)          # small folder: extract now
            if cover:
                li.setArt({'thumb': cover, 'poster': cover})
            else:
                li.setArt({'thumb': FALLBACK_ART, 'poster': FALLBACK_ART,
                           'icon': FALLBACK_ART})
                if not is_resolved(full):
                    need = _missing_reader(full)
                    if need:
                        missing_reader = missing_reader or need
                    else:
                        unresolved += 1
            item_url, read_url = _comic_urls(full)
            li.addContextMenuItems(
                [('Read from start', 'RunPlugin(%s)' % read_url)])
            # isFolder + the archive/plugin url: clicking descends into the
            # comic's pages in the Pictures window (then a page opens the
            # slideshow), reusing Kodi's native reader. We only override the
            # cover tile.
            xbmcplugin.addDirectoryItem(HANDLE, item_url, li, isFolder=True)
            if progress:
                progress.update(int((index + 1) * 100 / len(comics)))
    finally:
        if progress:
            progress.close()
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
    _pin_view(WALL_VIEW)

    # A comic here needs an archive reader that isn't installed (.cbr -> vfs.rar):
    # offer a one-tap install, once per session - BEFORE starting any warmer, so
    # Kodi's install dialog isn't fighting the wall's background refreshes.
    awaiting = ''
    if missing_reader and _prompt_install_reader(missing_reader):
        awaiting = missing_reader   # user chose Install; warmer waits + fills

    # Start the background warmer (a separate RunPlugin invocation that outlives
    # this listing) when there's resolvable work, or when the user just chose to
    # install a reader - then it waits for the install and fills these covers in.
    # Skip if one is already running.
    if (unresolved or awaiting) and \
            xbmcgui.Window(_HOME).getProperty(_BUSY_PROP) != '1':
        params = {'action': 'warm', 'dir': folder}
        if awaiting:
            params['await'] = awaiting
        xbmc.executebuiltin('RunPlugin(%s?%s)' % (BASE, urlencode(params)))


def _pin_view(view_id):
    """Pin a view in the Pictures window (a short sleep lets the container finish
    rendering first; the window guard keeps a stray call elsewhere a no-op)."""
    if xbmc.getCondVisibility('Window.IsVisible(MyPics.xml)'):
        xbmc.sleep(150)
        xbmc.executebuiltin('Container.SetViewMode(%d)' % view_id)


# ---- PDF reading ---------------------------------------------------------

def _pdf_pages_dir(path):
    return os.path.join(PAGES_DIR, _hash(path))


def _ensure_pdf_pages(path):
    """Extract a PDF's page JPEGs into a per-file cache folder (once) and return
    that folder, or '' if it holds no extractable pages. A '.done' sentinel marks
    a complete extraction so reopening is instant."""
    out = _pdf_pages_dir(path)
    done = os.path.join(out, '.done')
    if xbmcvfs.exists(done):
        return out
    if not xbmcvfs.exists(out):
        xbmcvfs.mkdirs(out)
    progress = xbmcgui.DialogProgressBG()
    progress.create('Navarre', 'Preparing comic')
    count = 0
    try:
        page_jpegs = pdfcomic.pages(_read_bytes(path))
        total = len(page_jpegs)
        for jpg in page_jpegs:
            count += 1
            _write_atomic(os.path.join(out, 'page_%04d.jpg' % count), jpg)
            progress.update(int(count * 100 / total) if total else 99, 'Navarre',
                            'Preparing comic (%d/%d pages)' % (count, total))
    except Exception as exc:
        _warn('PDF page extraction failed for "%s": %s'
              % (os.path.basename(path), exc))
    finally:
        progress.close()
    if not count:
        _warn('no extractable pages in "%s" (not a DCTDecode comic PDF)'
              % os.path.basename(path))
        return ''
    _touch(done)
    return out


def list_pdf_pages(path):
    """List a PDF's pages as image tiles (a contact sheet); clicking one opens
    Kodi's slideshow from that page, mirroring how .cbz/.cbr open."""
    xbmcplugin.setContent(HANDLE, 'images')
    pages = _ensure_pdf_pages(path)
    if not pages:
        xbmcgui.Dialog().notification(
            'Navarre', 'This PDF has no readable comic pages.',
            xbmcgui.NOTIFICATION_WARNING, 4000)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    try:
        _dirs, files = xbmcvfs.listdir(pages)
    except Exception:
        files = []
    for name in sorted((f for f in files if f.lower().endswith('.jpg')),
                       key=_natural_key):
        page = os.path.join(pages, name)
        li = xbmcgui.ListItem(label=_title(name))
        li.setArt({'thumb': page, 'icon': page})
        xbmcplugin.addDirectoryItem(HANDLE, page, li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
    _pin_view(PAGES_VIEW)


def list_archive_pages(path):
    """List a .cbz/.cbr's pages as tiles on the same poster wall the covers use,
    so opening a comic looks identical on every platform. Each tile points
    straight at the page inside the archive (rar://.../archive://), so clicking
    one opens Kodi's picture viewer there and the D-pad pages through the rest -
    no extraction, the bytes stream on demand."""
    xbmcplugin.setContent(HANDLE, 'images')
    if not path:
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    imgs = _walk_archive_images(path)
    if not imgs:
        # Most often the archive's reader isn't installed yet (a .cbr with no
        # vfs.rar lists nothing); the cover prompt on the folder already offers
        # to install it, so just say there's nothing to show.
        xbmcgui.Dialog().notification(
            'Navarre', 'No readable pages in this comic.',
            xbmcgui.NOTIFICATION_WARNING, 4000)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return
    for inner, url in imgs:
        name = inner.rsplit('/', 1)[-1]
        li = xbmcgui.ListItem(label=_title(name))
        li.setArt({'thumb': url, 'icon': url})
        xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)
    _pin_view(WALL_VIEW)


def read_archive(path):
    """Open a .cbz/.cbr full-screen from page 1 (the 'Read from start' action)."""
    if not path:
        return
    xbmc.executebuiltin('SlideShow(%s,notrandom)' % _archive_url(path))


def read_pdf(path):
    """Open a PDF full-screen from page 1 (extracting its pages first if needed)."""
    if not path:
        return
    pages = _ensure_pdf_pages(path)
    if pages:
        xbmc.executebuiltin('SlideShow(%s,notrandom)' % pages)


# ---- routing -------------------------------------------------------------

def router():
    params = {}
    if len(sys.argv) > 2 and sys.argv[2].startswith('?'):
        params = dict(parse_qsl(sys.argv[2][1:]))
    # parse_qsl has already percent-decoded the values, so use them as-is.
    action = params.get('action')
    if action == 'warm':
        warm(params.get('dir', ''), params.get('await', ''))
    elif action == 'read':
        read_archive(params.get('archive', ''))
    elif action == 'readpdf':
        read_pdf(params.get('pdf', ''))
    elif action == 'pdfpages':
        list_pdf_pages(params.get('pdf', ''))
    elif action == 'archivepages':
        list_archive_pages(params.get('archive', ''))
    else:
        list_dir(params.get('dir', ''))


if __name__ == '__main__':
    router()
