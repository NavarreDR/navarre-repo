# -*- coding: utf-8 -*-
"""Pure-Python comic-PDF reader: pull each page's JPEG out of a comic PDF, in
reading order, with no third-party library.

A scanned comic PDF stores each page as an embedded JPEG (an /XObject image with
/Filter /DCTDecode); the stream bytes ARE a complete JPEG. Many commercial comic
PDFs (e.g. the "40 Years of X-Men" DVD set) are wrapped in PDF Standard security
- RC4 with an empty user password, purely as copy-protection - so the stream
bytes are encrypted. We derive the key the spec's way (MD5 over the padded empty
password + /O + /P + /ID) and RC4-decrypt each stream; both MD5 and RC4 are pure
stdlib, so there is still no dependency.

Page ORDER comes from the page tree (/Root -> /Pages -> ordered /Kids), not file
order - in a real PDF the objects are not stored in page order (page 1 is often a
publisher logo sitting late in the file). We walk the tree, find each page's
image XObject, decrypt it, and hand back the JPEG.

This module is deliberately free of any xbmc* import so it can be unit-tested
against real PDFs off-device. The caller passes the file bytes in.

Public:
    cover(data)  -> bytes | None      first page's JPEG
    pages(data)  -> list[bytes]       every page's JPEG, in reading order

Scope / graceful fallback: handles classic xref PDFs with RC4 (V1/V2, R2/R3) or
no encryption, DCTDecode images (optionally Flate-wrapped). Anything it can't
read - AES (V4/V5), object/xref streams (PDF 1.5+ /ObjStm), pure non-JPEG images
- yields nothing for that page, so the caller falls back to a generic icon and
the comic still lists. Never raises to the caller.
"""
import re
import zlib
import struct
import hashlib

import jpegcrop  # sibling - trims the blank half off 2-page-spread covers

# Standard 32-byte password padding (PDF spec, Algorithm 2).
_PAD = bytes([0x28, 0xBF, 0x4E, 0x5E, 0x4E, 0x75, 0x8A, 0x41, 0x64, 0x00, 0x4E,
              0x56, 0xFF, 0xFA, 0x01, 0x08, 0x2E, 0x2E, 0x00, 0xB6, 0xD0, 0x68,
              0x3E, 0x80, 0x2F, 0x0C, 0xA9, 0xFE, 0x64, 0x53, 0x69, 0x7A])

_SOI = b'\xff\xd8'
_EOI = b'\xff\xd9'
_MAX_DEPTH = 60


def _rc4(key, data):
    """RC4 stream cipher (used for both the file key and per-object keys)."""
    s = list(range(256))
    j = 0
    klen = len(key)
    for i in range(256):
        j = (j + s[i] + key[i % klen]) & 0xFF
        s[i], s[j] = s[j], s[i]
    out = bytearray(len(data))
    i = j = 0
    for k in range(len(data)):
        i = (i + 1) & 0xFF
        j = (j + s[i]) & 0xFF
        s[i], s[j] = s[j], s[i]
        out[k] = data[k] ^ s[(s[i] + s[j]) & 0xFF]
    return bytes(out)


# ---- low-level string / object access ------------------------------------

def _read_string(data, i):
    """Parse a PDF object at data[i] when it is a literal '(...)' or hex '<...>'
    string. Returns (bytes, end_index) or (None, i)."""
    c = data[i:i + 1]
    if c == b'<':
        end = data.find(b'>', i)
        if end == -1:
            return None, i
        try:
            return bytes.fromhex(re.sub(rb'\s', b'', data[i + 1:end])
                                 .decode('latin1')), end + 1
        except ValueError:
            return None, i
    if c != b'(':
        return None, i
    i += 1
    depth = 1
    out = bytearray()
    esc = {0x6E: 0x0A, 0x72: 0x0D, 0x74: 0x09, 0x62: 0x08, 0x66: 0x0C,
           0x28: 0x28, 0x29: 0x29, 0x5C: 0x5C}
    n = len(data)
    while i < n:
        b = data[i]
        if b == 0x5C:                       # backslash escape
            nxt = data[i + 1] if i + 1 < n else 0
            if nxt in esc:
                out.append(esc[nxt]); i += 2; continue
            m = re.match(rb'[0-7]{1,3}', data[i + 1:i + 4])
            if m:
                out.append(int(m.group(), 8) & 0xFF); i += 1 + len(m.group())
                continue
            i += 2; continue
        if b == 0x28:
            depth += 1; out.append(b); i += 1; continue
        if b == 0x29:
            depth -= 1
            if depth == 0:
                return bytes(out), i + 1
            out.append(b); i += 1; continue
        out.append(b); i += 1
    return bytes(out), i


def _string_field(d, key):
    """Value of a string-valued dict key like /O or /U."""
    k = d.find(key)
    if k == -1:
        return None
    j = k + len(key)
    while d[j:j + 1] in (b' ', b'\r', b'\n', b'\t'):
        j += 1
    return _read_string(d, j)[0]


def _int_field(d, key, default=0):
    m = re.search(re.escape(key) + rb'\s*(-?\d+)', d)
    return int(m.group(1)) if m else default


def _refs(blob):
    """Object numbers of every 'N G R' indirect reference in a blob, in order."""
    return [int(m.group(1)) for m in re.finditer(rb'(\d+)\s+\d+\s+R', blob)]


class _Doc(object):
    """A parsed-on-demand classic-xref PDF. Builds a number->offset index by
    scanning for 'N G obj', then reads dicts/streams lazily."""

    def __init__(self, data):
        self.data = data
        self.index = {}
        for m in re.finditer(rb'(\d+)\s+(\d+)\s+obj\b', data):
            # last definition wins (honours incremental updates)
            self.index[int(m.group(1))] = (m.end(), int(m.group(2)))
        self.key = None     # file encryption key, or None when not encrypted
        self.keylen = 16
        self._setup_crypt()

    # -- raw object access --
    def obj_dict(self, num):
        """Dict region (bytes from after 'obj' up to 'stream' or 'endobj') for an
        object, or b'' if unknown."""
        ent = self.index.get(num)
        if not ent:
            return b''
        start = ent[0]
        s = self.data.find(b'stream', start)
        e = self.data.find(b'endobj', start)
        end = min(x for x in (s, e) if x != -1) if (s != -1 or e != -1) else start
        return self.data[start:end]

    def obj_stream(self, num):
        """Raw (still-encrypted) stream bytes of an object, or None."""
        ent = self.index.get(num)
        if not ent:
            return None
        start = ent[0]
        s = self.data.find(b'stream', start)
        e = self.data.find(b'endobj', start)
        if s == -1 or (e != -1 and s > e):
            return None
        st = s + 6
        if self.data[st:st + 2] == b'\r\n':
            st += 2
        elif self.data[st:st + 1] in (b'\r', b'\n'):
            st += 1
        d = self.data[ent[0]:s]
        ln = _int_field(d, b'/Length', -1)
        # /Length is sometimes an indirect ref; fall back to the endstream marker.
        if ln < 0 or re.search(rb'/Length\s+\d+\s+\d+\s+R', d):
            es = self.data.find(b'endstream', st)
            return self.data[st:es] if es != -1 else None
        return self.data[st:st + ln]

    # -- encryption --
    def _setup_crypt(self):
        em = re.search(rb'/Encrypt\s+(\d+)\s+\d+\s+R', self.data)
        if not em:
            return
        ed = self.obj_dict(int(em.group(1)))
        if b'/Standard' not in ed:
            return                              # unknown handler -> leave plaintext
        v = _int_field(ed, b'/V', 0)
        r = _int_field(ed, b'/R', 0)
        if v >= 4 or r >= 5:
            return                              # AES / newer -> unsupported, skip
        length = _int_field(ed, b'/Length', 40)
        o = _string_field(ed, b'/O')
        p = _int_field(ed, b'/P', 0)
        idm = re.search(rb'/ID\s*\[\s*<([0-9A-Fa-f\s]+)>', self.data)
        if not (o and idm):
            return
        id0 = bytes.fromhex(re.sub(rb'\s', b'', idm.group(1)).decode('latin1'))
        n = max(5, length // 8)
        h = hashlib.md5()
        h.update(_PAD)
        h.update(o[:32])
        h.update(struct.pack('<i', p))
        h.update(id0)
        key = h.digest()
        if r >= 3:
            for _ in range(50):
                key = hashlib.md5(key[:n]).digest()
        self.key = key[:n]
        self.keylen = n

    def decrypt(self, num, gen, raw):
        if self.key is None or raw is None:
            return raw
        ok = hashlib.md5(self.key + struct.pack('<I', num)[:3]
                         + struct.pack('<I', gen)[:2]).digest()[:min(self.keylen + 5, 16)]
        return _rc4(ok, raw)

    def gen_of(self, num):
        ent = self.index.get(num)
        return ent[1] if ent else 0

    # -- page tree --
    def _root_pages(self):
        rm = re.search(rb'/Root\s+(\d+)\s+\d+\s+R', self.data)
        if not rm:
            return None
        root = self.obj_dict(int(rm.group(1)))
        pm = re.search(rb'/Pages\s+(\d+)\s+\d+\s+R', root)
        return int(pm.group(1)) if pm else None

    def page_order(self):
        """Leaf page object numbers in reading order."""
        start = self._root_pages()
        if start is None:
            return []
        out = []
        self._walk(start, out, 0)
        return out

    def _walk(self, num, out, depth):
        if depth > _MAX_DEPTH or num in out:
            return
        d = self.obj_dict(num)
        if re.search(rb'/Type\s*/Pages', d):
            km = re.search(rb'/Kids\s*\[(.*?)\]', d, re.S)
            if km:
                for kid in _refs(km.group(1)):
                    self._walk(kid, out, depth + 1)
        elif re.search(rb'/Type\s*/Page\b', d) or b'/Contents' in d \
                or b'/MediaBox' in d:
            out.append(num)

    # -- per-page image --
    def _resources(self, page_num):
        """Resources dict bytes for a page, following an indirect /Resources and
        inheriting from /Parent when the page has none."""
        seen = set()
        num = page_num
        depth = 0
        while num is not None and num not in seen and depth < _MAX_DEPTH:
            seen.add(num)
            depth += 1
            d = self.obj_dict(num)
            rm = re.search(rb'/Resources\s+(\d+)\s+\d+\s+R', d)
            if rm:
                return self.obj_dict(int(rm.group(1)))
            rm = re.search(rb'/Resources\s*<<', d)
            if rm:
                return _balanced_dict(d, rm.end() - 2)
            pm = re.search(rb'/Parent\s+(\d+)\s+\d+\s+R', d)
            num = int(pm.group(1)) if pm else None
        return b''

    def _image_candidates(self, page_num):
        res = self._resources(page_num)
        if not res:
            return []
        xm = re.search(rb'/XObject\s+(\d+)\s+\d+\s+R', res)
        if xm:
            xdict = self.obj_dict(int(xm.group(1)))
        else:
            xm = re.search(rb'/XObject\s*<<', res)
            xdict = _balanced_dict(res, xm.end() - 2) if xm else b''
        return _refs(xdict)

    def page_jpeg(self, page_num):
        """Best page image for a page as JPEG bytes, or None. Chosen by stream
        byte size, not pixel dimensions: a near-blank image (a black/white panel,
        a menu-button state on the DVD-menu pages that carry a dozen same-size
        frames) compresses to almost nothing, while the real artwork is large -
        so the most-detailed image wins. A normal comic page has one dominant
        image, so this is identical to picking the obvious one there."""
        best = None
        best_score = -1
        for num in self._image_candidates(page_num):
            d = self.obj_dict(num)
            if b'/Image' not in d or b'/DCTDecode' not in d:
                continue
            raw = self.obj_stream(num)
            if raw is None:
                continue
            score = len(raw)
            if score <= best_score:
                continue
            data = self.decrypt(num, self.gen_of(num), raw)
            if b'/FlateDecode' in d:            # Flate then DCT -> inflate first
                try:
                    data = zlib.decompress(data)
                except Exception:
                    continue
            jpg = _trim_jpeg(data)
            if jpg:
                best, best_score = jpg, score
        return best


def _balanced_dict(blob, start):
    """Return the bytes of a '<< ... >>' dict beginning at `start`, matching
    nested << >>."""
    i = start
    depth = 0
    n = len(blob)
    while i < n - 1:
        pair = blob[i:i + 2]
        if pair == b'<<':
            depth += 1; i += 2; continue
        if pair == b'>>':
            depth -= 1; i += 2
            if depth == 0:
                return blob[start:i]
            continue
        i += 1
    return blob[start:]


def _trim_jpeg(data):
    """Given decrypted/inflated stream bytes, return the clean JPEG (SOI..last
    EOI) or None when it isn't a JPEG."""
    if data[:2] != _SOI:
        soi = data.find(_SOI)
        if soi == -1:
            return None
        data = data[soi:]
    e = data.rfind(_EOI)
    if e == -1:
        return None
    return data[:e + 2]


# ---- public API ----------------------------------------------------------

def _doc(data):
    try:
        return _Doc(data)
    except Exception:
        return None


def pages(data):
    """Every page's JPEG in reading order. Falls back to image objects in object
    order if the page tree yields nothing."""
    doc = _doc(data)
    if doc is None:
        return []
    out = []
    for num in doc.page_order():
        try:
            jpg = doc.page_jpeg(num)
        except Exception:
            jpg = None
        if jpg:
            out.append(jpg)
    if out:
        return out
    return _fallback_images(doc)


def cover(data):
    """First page's JPEG, or None. A 2-page-spread cover is trimmed to just the
    cover half (autocrop_cover returns it unchanged if it isn't a spread)."""
    doc = _doc(data)
    if doc is None:
        return None
    jpg = None
    for num in doc.page_order():
        try:
            jpg = doc.page_jpeg(num)
        except Exception:
            jpg = None
        if jpg:
            break
    if not jpg:
        imgs = _fallback_images(doc, limit=1)
        jpg = imgs[0] if imgs else None
    return jpegcrop.autocrop_cover(jpg) if jpg else None


def _fallback_images(doc, limit=None):
    """Last resort when the page tree is unreadable: every /Image /DCTDecode
    object, in object-number order (a decent approximation of page order in a
    linearized comic PDF)."""
    out = []
    for num in sorted(doc.index):
        d = doc.obj_dict(num)
        if b'/Image' not in d or b'/DCTDecode' not in d:
            continue
        raw = doc.obj_stream(num)
        if raw is None:
            continue
        data = doc.decrypt(num, doc.gen_of(num), raw)
        if b'/FlateDecode' in d:
            try:
                data = zlib.decompress(data)
            except Exception:
                continue
        jpg = _trim_jpeg(data)
        if jpg:
            out.append(jpg)
            if limit and len(out) >= limit:
                break
    return out
