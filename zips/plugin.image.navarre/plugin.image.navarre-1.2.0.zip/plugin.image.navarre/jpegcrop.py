# -*- coding: utf-8 -*-
"""Trim the blank half off a 2-page-spread comic cover, in pure Python.

Many commercial comic PDFs are scanned two pages to a sheet, so page 1 is a
LANDSCAPE image holding the cover on one half and a blank/black panel on the
other. Kodi center-crops that into the portrait tile, leaving a black margin and
an off-centre cover. There is no image library in Kodi's Python, so we fix it by
transcoding the JPEG itself: decode the quantised DCT coefficients (entropy layer
only - NO inverse-DCT, so it stays fast and lossless), find the blank edge
columns from the luma DC activity, and re-encode just the content columns.

Restricted to the baseline JPEGs these scans actually use: SOF0, 8-bit, 1 or 3
components, no restart markers (a file with /DRI is left untouched). Anything
outside that, any landscape image that ISN'T a one-sided spread, or any failure,
returns the input unchanged - so a cover is never corrupted, at worst un-trimmed.

Public:  autocrop_cover(jpeg_bytes) -> jpeg_bytes
"""
from array import array

# ---- standard Annex K Huffman tables (used for the OUTPUT, so every re-based
# DC differential and every coefficient is guaranteed encodable) --------------
_STD_DC_LUMA = ([0, 1, 5, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0],
                list(range(12)))
_STD_DC_CHROMA = ([0, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0],
                  list(range(12)))
_STD_AC_LUMA = (
    [0, 2, 1, 3, 3, 2, 4, 3, 5, 5, 4, 4, 0, 0, 1, 0x7d],
    [0x01, 0x02, 0x03, 0x00, 0x04, 0x11, 0x05, 0x12, 0x21, 0x31, 0x41, 0x06,
     0x13, 0x51, 0x61, 0x07, 0x22, 0x71, 0x14, 0x32, 0x81, 0x91, 0xa1, 0x08,
     0x23, 0x42, 0xb1, 0xc1, 0x15, 0x52, 0xd1, 0xf0, 0x24, 0x33, 0x62, 0x72,
     0x82, 0x09, 0x0a, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x25, 0x26, 0x27, 0x28,
     0x29, 0x2a, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3a, 0x43, 0x44, 0x45,
     0x46, 0x47, 0x48, 0x49, 0x4a, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58, 0x59,
     0x5a, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68, 0x69, 0x6a, 0x73, 0x74, 0x75,
     0x76, 0x77, 0x78, 0x79, 0x7a, 0x83, 0x84, 0x85, 0x86, 0x87, 0x88, 0x89,
     0x8a, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97, 0x98, 0x99, 0x9a, 0xa2, 0xa3,
     0xa4, 0xa5, 0xa6, 0xa7, 0xa8, 0xa9, 0xaa, 0xb2, 0xb3, 0xb4, 0xb5, 0xb6,
     0xb7, 0xb8, 0xb9, 0xba, 0xc2, 0xc3, 0xc4, 0xc5, 0xc6, 0xc7, 0xc8, 0xc9,
     0xca, 0xd2, 0xd3, 0xd4, 0xd5, 0xd6, 0xd7, 0xd8, 0xd9, 0xda, 0xe1, 0xe2,
     0xe3, 0xe4, 0xe5, 0xe6, 0xe7, 0xe8, 0xe9, 0xea, 0xf1, 0xf2, 0xf3, 0xf4,
     0xf5, 0xf6, 0xf7, 0xf8, 0xf9, 0xfa])
_STD_AC_CHROMA = (
    [0, 2, 1, 2, 4, 4, 3, 4, 7, 5, 4, 4, 0, 1, 2, 0x77],
    [0x00, 0x01, 0x02, 0x03, 0x11, 0x04, 0x05, 0x21, 0x31, 0x06, 0x12, 0x41,
     0x51, 0x07, 0x61, 0x71, 0x13, 0x22, 0x32, 0x81, 0x08, 0x14, 0x42, 0x91,
     0xa1, 0xb1, 0xc1, 0x09, 0x23, 0x33, 0x52, 0xf0, 0x15, 0x62, 0x72, 0xd1,
     0x0a, 0x16, 0x24, 0x34, 0xe1, 0x25, 0xf1, 0x17, 0x18, 0x19, 0x1a, 0x26,
     0x27, 0x28, 0x29, 0x2a, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3a, 0x43, 0x44,
     0x45, 0x46, 0x47, 0x48, 0x49, 0x4a, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58,
     0x59, 0x5a, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68, 0x69, 0x6a, 0x73, 0x74,
     0x75, 0x76, 0x77, 0x78, 0x79, 0x7a, 0x82, 0x83, 0x84, 0x85, 0x86, 0x87,
     0x88, 0x89, 0x8a, 0x92, 0x93, 0x94, 0x95, 0x96, 0x97, 0x98, 0x99, 0x9a,
     0xa2, 0xa3, 0xa4, 0xa5, 0xa6, 0xa7, 0xa8, 0xa9, 0xaa, 0xb2, 0xb3, 0xb4,
     0xb5, 0xb6, 0xb7, 0xb8, 0xb9, 0xba, 0xc2, 0xc3, 0xc4, 0xc5, 0xc6, 0xc7,
     0xc8, 0xc9, 0xca, 0xd2, 0xd3, 0xd4, 0xd5, 0xd6, 0xd7, 0xd8, 0xd9, 0xda,
     0xe2, 0xe3, 0xe4, 0xe5, 0xe6, 0xe7, 0xe8, 0xe9, 0xea, 0xf2, 0xf3, 0xf4,
     0xf5, 0xf6, 0xf7, 0xf8, 0xf9, 0xfa])

# tuning
_LANDSCAPE_AR = 1.15      # only spreads (clearly wider than tall) are candidates
_BLANK_FRAC = 0.05        # a column under 5% of peak DC activity counts as blank
_MIN_TRIM_FRAC = 0.10     # trim must remove >=10% of width to bother
_MIN_KEEP_FRAC = 0.25     # never keep less than 25% of width (sanity guard)


class _Abort(Exception):
    """Raised to bail out and return the original JPEG unchanged."""


# ---- Huffman ----------------------------------------------------------------

def _canonical(counts, vals):
    """Yield (length, code, value) for a JPEG Huffman table (Annex C order)."""
    code = 0
    k = 0
    for length in range(1, 17):
        for _ in range(counts[length - 1]):
            yield length, code, vals[k]
            k += 1
            code += 1
        code <<= 1


def _decode_lut(counts, vals):
    """16-bit lookup table: index by the next 16 bits, get (nbits, value)."""
    lut = [(0, 0)] * 65536
    for length, code, value in _canonical(counts, vals):
        start = code << (16 - length)
        for x in range(start, start + (1 << (16 - length))):
            lut[x] = (length, value)
    return lut


def _encode_map(counts, vals):
    """value -> (code, nbits) for writing the output stream."""
    return {value: (code, length)
            for length, code, value in _canonical(counts, vals)}


_ENC_DC = (_encode_map(*_STD_DC_LUMA), _encode_map(*_STD_DC_CHROMA))
_ENC_AC = (_encode_map(*_STD_AC_LUMA), _encode_map(*_STD_AC_CHROMA))


# ---- bit IO -----------------------------------------------------------------

class _Reader:
    """MSB-first bit reader over the entropy segment, undoing 0xFF00 stuffing.
    Any other marker (or the end) pads with 1-bits; callers don't hit it because
    /DRI files are rejected up front and the scan length is exact."""

    def __init__(self, data, start):
        self.d = data
        self.pos = start
        self.acc = 0
        self.cnt = 0

    def _fill(self):
        d = self.d
        n = len(d)
        while self.cnt <= 24:
            if self.pos >= n:
                self.acc = (self.acc << 8) | 0xFF
                self.cnt += 8
                continue
            b = d[self.pos]
            if b == 0xFF:
                nxt = d[self.pos + 1] if self.pos + 1 < n else 0xD9
                if nxt == 0x00:
                    self.pos += 2
                else:
                    self.acc = (self.acc << 8) | 0xFF   # marker -> pad
                    self.cnt += 8
                    continue
            else:
                self.pos += 1
            self.acc = (self.acc << 8) | b
            self.cnt += 8

    def peek16(self):
        if self.cnt < 16:
            self._fill()
        return (self.acc >> (self.cnt - 16)) & 0xFFFF

    def drop(self, n):
        # Mask off the bits we just consumed so `acc` stays a small int. Without
        # this it grows unbounded and every `acc << 8` in _fill turns O(n) - the
        # whole decode then runs O(n^2).
        self.cnt -= n
        self.acc &= (1 << self.cnt) - 1

    def bits(self, n):
        if n == 0:
            return 0
        if self.cnt < n:
            self._fill()
        self.cnt -= n
        r = (self.acc >> self.cnt) & ((1 << n) - 1)
        self.acc &= (1 << self.cnt) - 1
        return r


class _Writer:
    """MSB-first bit writer, applying 0xFF00 byte stuffing."""

    def __init__(self):
        self.out = bytearray()
        self.acc = 0
        self.cnt = 0

    def put(self, code, n):
        if n == 0:
            return
        self.acc = (self.acc << n) | (code & ((1 << n) - 1))
        self.cnt += n
        while self.cnt >= 8:
            self.cnt -= 8
            b = (self.acc >> self.cnt) & 0xFF
            self.out.append(b)
            if b == 0xFF:
                self.out.append(0x00)
        # Drop the bytes we just emitted so `acc` stays small (else it grows
        # unbounded and every shift here turns O(n) - this loop was the single
        # hottest spot in the crop).
        self.acc &= (1 << self.cnt) - 1

    def flush(self):
        if self.cnt:
            pad = 8 - self.cnt
            b = ((self.acc << pad) | ((1 << pad) - 1)) & 0xFF
            self.out.append(b)
            if b == 0xFF:
                self.out.append(0x00)
            self.cnt = 0


def _receive_extend(br, s):
    if s == 0:
        return 0
    v = br.bits(s)
    if v < (1 << (s - 1)):
        v -= (1 << s) - 1
    return v


def _magnitude(v):
    a = v if v >= 0 else -v
    s = 0
    while a:
        a >>= 1
        s += 1
    return s


# ---- JPEG structure parse ---------------------------------------------------

def _parse(j):
    """Pull the segments we need from a baseline JPEG. Raises _Abort for
    anything we don't handle."""
    if j[:2] != b'\xff\xd8':
        raise _Abort
    seg = {'dqt': [], 'dht': {}, 'dri': 0}
    i = 2
    n = len(j)
    while i < n - 1:
        if j[i] != 0xFF:
            raise _Abort
        m = j[i + 1]
        if m == 0xD9:
            break
        ln = (j[i + 2] << 8) | j[i + 3]
        body = j[i + 4:i + 2 + ln]
        if m in (0xC2, 0xC3, 0xC5, 0xC6, 0xC7, 0xC9, 0xCA, 0xCB):
            raise _Abort                       # progressive / arithmetic / etc.
        if m == 0xC0:                          # SOF0 baseline
            if body[0] != 8:
                raise _Abort
            seg['h'] = (body[1] << 8) | body[2]
            seg['w'] = (body[3] << 8) | body[4]
            nc = body[5]
            if nc not in (1, 3):
                raise _Abort
            comps = []
            for c in range(nc):
                cid = body[6 + c * 3]
                samp = body[7 + c * 3]
                comps.append({'id': cid, 'H': samp >> 4, 'V': samp & 0xF,
                              'q': body[8 + c * 3]})
            seg['comps'] = comps
        elif m == 0xC4:                        # DHT (may pack several tables)
            p = 0
            while p < len(body):
                tc_th = body[p]
                counts = list(body[p + 1:p + 17])
                total = sum(counts)
                vals = list(body[p + 17:p + 17 + total])
                seg['dht'][(tc_th >> 4, tc_th & 0xF)] = (counts, vals)
                p += 17 + total
        elif m == 0xDB:                        # DQT (copied verbatim to output)
            seg['dqt'].append(j[i:i + 2 + ln])
        elif m == 0xDD:                        # restart interval -> we skip such
            seg['dri'] = (body[0] << 8) | body[1]
        elif m == 0xDA:                        # SOS
            ns = body[0]
            scan = []
            for c in range(ns):
                cs = body[1 + c * 2]
                td_ta = body[2 + c * 2]
                scan.append({'id': cs, 'dc': td_ta >> 4, 'ac': td_ta & 0xF})
            seg['scan'] = scan
            seg['scan_start'] = i + 2 + ln
            return seg
        i += 2 + ln
    raise _Abort


# ---- output assembly --------------------------------------------------------

def _std_dht_segment():
    out = bytearray(b'\xff\xc4')
    payload = bytearray()
    for tc_th, (counts, vals) in ((0x00, _STD_DC_LUMA), (0x10, _STD_AC_LUMA),
                                  (0x01, _STD_DC_CHROMA), (0x11, _STD_AC_CHROMA)):
        payload.append(tc_th)
        payload += bytes(counts)
        payload += bytes(vals)
    ln = len(payload) + 2
    out += bytes([ln >> 8, ln & 0xFF]) + payload
    return out


def _jfif_app0():
    body = b'JFIF\x00\x01\x01\x00\x00\x01\x00\x01\x00\x00'
    ln = len(body) + 2
    return b'\xff\xe0' + bytes([ln >> 8, ln & 0xFF]) + body


def _sof0(width, height, comps):
    body = bytearray([8, height >> 8, height & 0xFF, width >> 8, width & 0xFF,
                      len(comps)])
    for c in comps:
        body += bytes([c['id'], (c['H'] << 4) | c['V'], c['q']])
    ln = len(body) + 2
    return b'\xff\xc0' + bytes([ln >> 8, ln & 0xFF]) + bytes(body)


def _sos(comps):
    # luma (first component) -> tables 0/0, chroma -> 1/1 (matches std DHT above)
    body = bytearray([len(comps)])
    for idx, c in enumerate(comps):
        t = 0 if idx == 0 else 1
        body += bytes([c['id'], (t << 4) | t])
    body += bytes([0, 63, 0])
    ln = len(body) + 2
    return b'\xff\xda' + bytes([ln >> 8, ln & 0xFF]) + bytes(body)


# ---- the transcode ----------------------------------------------------------

def autocrop_cover(jpeg):
    """Return a JPEG trimmed to the cover when the input is a one-sided spread;
    otherwise return the input unchanged. Never raises."""
    try:
        return _crop(jpeg)
    except _Abort:
        return jpeg
    except Exception:
        return jpeg


def _crop(j):
    seg = _parse(j)
    if seg['dri']:
        raise _Abort                           # restart markers -> leave alone
    w, h = seg['w'], seg['h']
    if w <= h * _LANDSCAPE_AR:
        raise _Abort                           # not a landscape spread
    comps = seg['comps']
    hmax = max(c['H'] for c in comps)
    vmax = max(c['V'] for c in comps)
    mcu_w = hmax * 8
    mcu_h = vmax * 8
    mcus_x = (w + mcu_w - 1) // mcu_w
    mcus_y = (h + mcu_h - 1) // mcu_h

    # decode tables, per component, from the file's own DHT via the SOS mapping
    scan_by_id = {s['id']: s for s in seg['scan']}
    dec = []
    for c in comps:
        s = scan_by_id[c['id']]
        try:
            dc_lut = _decode_lut(*seg['dht'][(0, s['dc'])])
            ac_lut = _decode_lut(*seg['dht'][(1, s['ac'])])
        except KeyError:
            raise _Abort
        dec.append((dc_lut, ac_lut))
    blocks_per_mcu = sum(c['H'] * c['V'] for c in comps)
    total_blocks = mcus_x * mcus_y * blocks_per_mcu
    coeff = array('h', bytes(2 * 64 * total_blocks))   # zero-filled, ~ compact

    # --- decode every block (entropy only), recording luma DC activity ---
    br = _Reader(j, seg['scan_start'])
    pred = [0] * len(comps)
    col_dc = [[] for _ in range(mcus_x)]   # luma block DC values, per MCU column
    bi = 0
    for my in range(mcus_y):
        for mx in range(mcus_x):
            for ci, c in enumerate(comps):
                dc_lut, ac_lut = dec[ci]
                for _b in range(c['H'] * c['V']):
                    base = bi * 64
                    # DC
                    nb, sval = dc_lut[br.peek16()]
                    if nb == 0:
                        raise _Abort
                    br.drop(nb)
                    diff = _receive_extend(br, sval)
                    dcv = pred[ci] + diff
                    pred[ci] = dcv
                    if dcv < -32768 or dcv > 32767:
                        raise _Abort
                    coeff[base] = dcv
                    if ci == 0:                # luma -> activity
                        col_dc[mx].append(dcv)
                    # AC
                    k = 1
                    while k < 64:
                        nb, rs = ac_lut[br.peek16()]
                        if nb == 0:
                            raise _Abort
                        br.drop(nb)
                        r = rs >> 4
                        sz = rs & 0xF
                        if sz == 0:
                            if r == 15:
                                k += 16
                                continue
                            break              # EOB
                        k += r
                        if k >= 64:
                            break
                        val = _receive_extend(br, sz)
                        if val < -32768 or val > 32767:
                            raise _Abort
                        coeff[base + k] = val
                        k += 1
                    bi += 1

    # --- decide the crop columns from luma DC activity ---
    # Interquartile range, not max-min: a blank panel often carries a thin
    # copyright line, and the IQR ignores those few outlier rows so the panel
    # still reads as blank.
    def _iqr(vals):
        if not vals:
            return 0
        s = sorted(vals)
        n = len(s)
        return s[(3 * n) // 4] - s[n // 4]

    activity = [_iqr(col_dc[x]) for x in range(mcus_x)]
    peak = max(activity) if activity else 0
    if peak <= 0:
        raise _Abort
    thresh = peak * _BLANK_FRAC
    c0 = 0
    while c0 < mcus_x and activity[c0] < thresh:
        c0 += 1
    c1 = mcus_x - 1
    while c1 >= 0 and activity[c1] < thresh:
        c1 -= 1
    if c1 < c0:
        raise _Abort
    keep = c1 - c0 + 1
    trimmed = mcus_x - keep
    if trimmed < mcus_x * _MIN_TRIM_FRAC:
        raise _Abort                           # nothing worth trimming
    if keep < mcus_x * _MIN_KEEP_FRAC:
        raise _Abort                           # would crop too aggressively

    # --- re-encode the kept MCU columns (no restart markers) ---
    bw = _Writer()
    opred = [0] * len(comps)
    for my in range(mcus_y):
        for mx in range(c0, c1 + 1):
            mcu_index = my * mcus_x + mx
            local = 0
            for ci, c in enumerate(comps):
                dc_enc = _ENC_DC[0 if ci == 0 else 1]
                ac_enc = _ENC_AC[0 if ci == 0 else 1]
                for _b in range(c['H'] * c['V']):
                    base = (mcu_index * blocks_per_mcu + local) * 64
                    local += 1
                    dcv = coeff[base]
                    diff = dcv - opred[ci]
                    opred[ci] = dcv
                    s = _magnitude(diff)
                    code = dc_enc.get(s)
                    if code is None:
                        raise _Abort
                    bw.put(code[0], code[1])
                    if s:
                        bw.put(diff if diff >= 0 else diff + (1 << s) - 1, s)
                    run = 0
                    for k in range(1, 64):
                        cv = coeff[base + k]
                        if cv == 0:
                            run += 1
                            continue
                        while run > 15:
                            zrl = ac_enc.get(0xF0)
                            if zrl is None:
                                raise _Abort
                            bw.put(zrl[0], zrl[1])
                            run -= 16
                        s = _magnitude(cv)
                        sym = ac_enc.get((run << 4) | s)
                        if sym is None:
                            raise _Abort
                        bw.put(sym[0], sym[1])
                        bw.put(cv if cv >= 0 else cv + (1 << s) - 1, s)
                        run = 0
                    if run:
                        eob = ac_enc.get(0x00)
                        if eob is None:
                            raise _Abort
                        bw.put(eob[0], eob[1])
    bw.flush()

    out_w = min(keep * mcu_w, w - c0 * mcu_w)
    out = bytearray(b'\xff\xd8')
    out += _jfif_app0()
    for dqt in seg['dqt']:
        out += dqt
    out += _std_dht_segment()
    out += _sof0(out_w, h, comps)
    out += _sos(comps)
    out += bw.out
    out += b'\xff\xd9'
    return bytes(out)
