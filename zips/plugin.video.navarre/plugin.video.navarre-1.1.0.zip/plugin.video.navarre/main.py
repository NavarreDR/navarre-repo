"""plugin.video.navarre - Continue watching content for the Navarre skin.

Lists videos you have started (Kodi's resume points), newest first, so the skin
can show a "Continue watching" row. Works in files mode: Kodi records a resume
point and last-played time for ANY file you play, even without a library, in its
own video database. We read that database read-only - no library scan, no extra
tracking service - and turn each in-progress file into a playable, resumable
tile. Each tile carries a "Remove from Continue watching" context action.

Routes:
  plugin://plugin.video.navarre/                 -> list in-progress videos
  plugin://plugin.video.navarre/?action=remove&file=<path>  -> drop one item
"""
import sys
import os
import glob
import json
import sqlite3
from urllib.parse import urlencode, parse_qsl

import xbmc
import xbmcgui
import xbmcvfs
import xbmcplugin

HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
BASE = sys.argv[0]
MAX_ITEMS = 25


def _log(msg):
    xbmc.log('[plugin.video.navarre] %s' % msg, xbmc.LOGDEBUG)


def _db_path():
    """Kodi's own video DB lives in special://database as MyVideosNN.db; the
    NN changes between Kodi versions, so pick the highest-numbered one."""
    folder = xbmcvfs.translatePath('special://database/')
    found = sorted(glob.glob(os.path.join(folder, 'MyVideos*.db')))
    return found[-1] if found else None


def _query_in_progress():
    """Files with a live resume bookmark (type 1), newest first. Read-only so we
    never fight Kodi for the DB; a short busy timeout rides out brief writes."""
    path = _db_path()
    if not path:
        return []
    try:
        uri = 'file:%s?mode=ro' % path.replace('?', '%3f')
        conn = sqlite3.connect(uri, uri=True, timeout=1.0)
    except Exception as exc:
        _log('db open failed: %s' % exc)
        return []
    try:
        conn.execute('PRAGMA busy_timeout=1500')
        rows = conn.execute(
            """select p.strPath, f.strFilename, b.timeInSeconds, b.totalTimeInSeconds
                 from bookmark b
                 join files f on f.idFile = b.idFile
                 join path  p on p.idPath = f.idPath
                where b.type = 1 and b.timeInSeconds > 0
             order by f.lastPlayed desc
                limit ?""", (MAX_ITEMS,)).fetchall()
    except Exception as exc:
        _log('query failed: %s' % exc)
        rows = []
    finally:
        conn.close()
    items = []
    for strpath, filename, secs, total in rows:
        if not filename:
            continue
        items.append({
            'path': (strpath or '') + filename,   # strPath keeps its trailing sep
            'name': filename,
            'resume': float(secs or 0),
            'total': float(total or 0),
        })
    return items


def _title(filename):
    """A clean on-screen label: drop the extension (the year, if present, is
    fine to keep - it disambiguates)."""
    dot = filename.rfind('.')
    return filename[:dot] if dot > 0 else filename


def _poster(path):
    """Navarre is files-based, so art is the sidecar next to the file:
    <base>-poster.jpg first, then a folder poster. Handles both / and \\ paths
    (Windows local vs Android/SMB)."""
    dot = path.rfind('.')
    base = path[:dot] if dot > 0 else path
    sep = max(path.rfind('/'), path.rfind('\\'))
    folder = path[:sep + 1] if sep >= 0 else ''
    for cand in (base + '-poster.jpg', base + '-poster.png',
                 folder + 'poster.jpg', folder + 'folder.jpg'):
        if cand and xbmcvfs.exists(cand):
            return cand
    return ''


def list_in_progress():
    xbmcplugin.setContent(HANDLE, 'movies')
    for it in _query_in_progress():
        li = xbmcgui.ListItem(label=_title(it['name']))
        poster = _poster(it['path'])
        if poster:
            li.setArt({'poster': poster, 'thumb': poster})
        li.setProperty('IsPlayable', 'true')
        # Carry the resume point so the tile shows a progress bar and playback
        # resumes where it stopped.
        if it['resume'] > 0 and it['total'] > 0:
            li.setProperty('ResumeTime', str(int(it['resume'])))
            li.setProperty('TotalTime', str(int(it['total'])))
            try:
                li.getVideoInfoTag().setResumePoint(it['resume'], it['total'])
            except Exception:
                pass
        remove_url = BASE + '?' + urlencode({'action': 'remove', 'file': it['path']})
        clearall_url = BASE + '?' + urlencode({'action': 'clearall'})
        li.addContextMenuItems([
            ('Remove from Continue watching', 'RunPlugin(%s)' % remove_url),
            ('Clear all Continue watching', 'RunPlugin(%s)' % clearall_url),
        ])
        xbmcplugin.addDirectoryItem(HANDLE, it['path'], li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


def _clear_resume(path):
    """Clear one file's resume point via JSON-RPC (Files.SetFileDetails) so Kodi
    performs the DB write safely rather than us writing the live database.
    Clearing resume (not marking watched) matches the intent: 'take this off my
    list', without touching watched state."""
    if not path:
        return
    request = {
        'jsonrpc': '2.0', 'id': 1, 'method': 'Files.SetFileDetails',
        'params': {'file': path, 'media': 'video',
                   'resume': {'position': 0, 'total': 0}},
    }
    xbmc.executeJSONRPC(json.dumps(request))


def remove(path):
    """Drop one item from Continue watching."""
    _clear_resume(path)
    xbmc.executebuiltin('Container.Refresh')


def clear_all():
    """Empty the whole Continue watching list, after a confirm."""
    if not xbmcgui.Dialog().yesno('Continue watching',
                                  'Clear the whole Continue watching list?'):
        return
    for it in _query_in_progress():
        _clear_resume(it['path'])
    xbmc.executebuiltin('Container.Refresh')


def router():
    params = {}
    if len(sys.argv) > 2 and sys.argv[2].startswith('?'):
        params = dict(parse_qsl(sys.argv[2][1:]))
    action = params.get('action')
    if action == 'remove':
        remove(params.get('file', ''))
    elif action == 'clearall':
        clear_all()
    else:
        list_in_progress()


if __name__ == '__main__':
    router()
