"""plugin.video.navarre service - keep Navarre's Kodi keymap tidy.

The Navarre skin installs a global Kodi keymap (userdata/keymaps/navarre_back.xml)
for its Back-to-sidebar and Back-stops-playback behavior. Kodi keymaps live in
userdata, not in the skin folder, and a skin has no "on uninstall" hook - so when
someone removes the Navarre skin the keymap is left behind. It then keeps firing
RunScript(special://skin/...back_to_sidebar.py), which now resolves to whatever
skin is active (where that script does not exist), spamming kodi.log on every Back
press and hijacking Back in the other skin. (Reported by a user, 2026-06-27.)

This add-on ships as a dependency of the skin, so it stays installed after the
skin is removed - which lets it do the cleanup the skin itself cannot:

  - Navarre is NOT the active skin, but the keymap is present  -> delete it
    (this is the leftover-on-uninstall case the user hit).
  - Navarre IS the active skin, but the keymap is missing      -> re-add it
    from the skin (covers a temporary skin switch, or a failed first-run copy).

The cleanup (delete) path only runs when Navarre is NOT active, so a bug here can
never break Back for someone actually using the skin. Logs to kodi.log only (no
stray files left in userdata).
"""
import xbmc
import xbmcvfs

SKIN_ID = 'skin.navarre'
KEYMAP_DEST = 'special://profile/keymaps/navarre_back.xml'
KEYMAP_DIR = 'special://profile/keymaps/'
# Resolves to the active skin's folder - valid ONLY while Navarre is active,
# which is exactly when we ever copy FROM it.
KEYMAP_SRC = 'special://skin/extras/keymaps/navarre_back.xml'
POLL_SECS = 10


def _log(msg):
    xbmc.log('[plugin.video.navarre.service] ' + msg, xbmc.LOGINFO)


def _reconcile():
    """Bring the keymap in line with whether Navarre is the active skin."""
    skin = xbmc.getSkinDir() or ''
    if not skin:
        return  # skin not resolved yet (early startup); act on a later pass
    is_navarre = (skin == SKIN_ID)
    present = xbmcvfs.exists(KEYMAP_DEST)

    if not is_navarre and present:
        # Orphaned keymap from a previous Navarre install - remove it so Back
        # behaves normally in the current skin and stops erroring in the log.
        if xbmcvfs.delete(KEYMAP_DEST):
            xbmc.executebuiltin('Action(reloadkeymaps)')
            _log('removed orphaned navarre_back.xml (active skin: %s)' % skin)
    elif is_navarre and not present:
        # Navarre is active but the keymap is gone (e.g. removed during a brief
        # switch to another skin) - put it back so Back/Stop work again.
        try:
            if not xbmcvfs.exists(KEYMAP_DIR):
                xbmcvfs.mkdirs(KEYMAP_DIR)
            if xbmcvfs.copy(KEYMAP_SRC, KEYMAP_DEST):
                xbmc.executebuiltin('Action(reloadkeymaps)')
                _log('restored navarre_back.xml for the active Navarre skin')
        except Exception as exc:
            _log('keymap restore error: %s' % exc)


def main():
    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        try:
            _reconcile()
        except Exception as exc:
            _log('reconcile error: %s' % exc)
        if monitor.waitForAbort(POLL_SECS):
            break


if __name__ == '__main__':
    main()
